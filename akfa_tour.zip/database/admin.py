from django.contrib import admin
from .models import *


admin.site.register(Country)
admin.site.register(Carrier)
admin.site.register(Citizenship)
admin.site.register(CompanyOffered)
