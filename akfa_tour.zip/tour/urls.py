from django.urls import path
from tour.views import (
    form_view,
    SearchResultsView,
    SearchFormView,
    ChooseGuestTypeView,
    form_present_view,
    success_view
)

urlpatterns = [
    path('', ChooseGuestTypeView.as_view(), name='choose-guest-type'),

    path('search/', SearchFormView.as_view(), name='search-form'),
    path('search/result/', SearchResultsView.as_view(), name='search-result'),

    path('contact/form/', form_view, name='form'),
    path('contact/form/<int:pk>/', form_present_view, name='form-present'),

    path('success/', success_view, name='success'),
]