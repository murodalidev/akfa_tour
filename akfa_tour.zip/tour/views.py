from django.db.models import Q
from django.shortcuts import render, redirect
from django.views.generic import TemplateView, ListView

from tour.forms import GuestInfoForm, PersonalManagerForm
from tour.models import GuestInfo, VisaControl


def form_view(request):
    if request.method == 'POST':
        guest_form = GuestInfoForm(request.POST)
        personal_manager_form = PersonalManagerForm(request.POST)

        if personal_manager_form.is_valid() and guest_form.is_valid():
            guest_instance = guest_form.save()

            personal_manager_instance = personal_manager_form.save(commit=False)
            personal_manager_instance.guest = guest_instance
            personal_manager_instance.save()

            return redirect('success')
    else:
        guest_form = GuestInfoForm()
        personal_manager_form = PersonalManagerForm()
    context = {'personal_manager_form': personal_manager_form,
               'guest_form': guest_form,
               }
    return render(request, 'tour/form.html', context)


def form_present_view(request, pk):
    guests = GuestInfo.objects.get(id=pk)
    if request.method == 'POST':
        # guest_form = GuestInfoForm(request.POST)
        personal_manager_form = PersonalManagerForm(request.POST)

        if personal_manager_form.is_valid():

            personal_manager_instance = personal_manager_form.save(commit=False)
            personal_manager_instance.guest = guests
            personal_manager_instance.save()

            return redirect('success')
    else:
        personal_manager_form = PersonalManagerForm()
    context = {'personal_manager_form': personal_manager_form,
               'guest_form': guests,
               }
    return render(request, 'tour/form_present.html', context)


class ChooseGuestTypeView(ListView):
    template_name = 'tour/choose_guest_type.html'


class SearchFormView(TemplateView):
    template_name = 'tour/search_form.html'


class SearchResultsView(ListView):
    model = GuestInfo
    template_name = 'tour/search_result.html'

    def get_queryset(self):  # new
        query = self.request.GET.get('q')
        object_list = GuestInfo.objects.filter(
            Q(guest_full_name__icontains=query) | Q(name_foreign_company__icontains=query)
        )
        return object_list


def success_view(request):

    return render(request, 'tour/success.html')
